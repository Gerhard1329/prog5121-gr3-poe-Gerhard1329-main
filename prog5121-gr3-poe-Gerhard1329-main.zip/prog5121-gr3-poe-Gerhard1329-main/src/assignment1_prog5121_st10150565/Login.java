/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment1_prog5121_st10150565;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class Login {

    String username; // ="Kyl_1";
    String password ;//= "Ch&&sec@ke99!";
    String firstname;// = "Khuli";
    String lastname ;//= "Mathabathe";
    
    
    


    public static void main(String[] args) {
       Scanner keyboardInput= new Scanner(System.in);
       
       
       String usernamaFromUser;
       String passwordFromUser;
       String firstname;
       String lastname;
       
       System.out.println("Enter a username");
       usernamaFromUser= keyboardInput.nextLine();
       
       System.out.println("Enter a password");
       passwordFromUser= keyboardInput.nextLine();
       
       
       System.out.println("Enter your firstname");
       firstname= keyboardInput.nextLine();
       
       System.out.println("Enter your lastname");
       lastname= keyboardInput.nextLine();
       System.out.println();
       
       Login newUser= new Login();
       String registrationOutcome = newUser.registerUser(usernamaFromUser, passwordFromUser, firstname, lastname);
       System.out.println(registrationOutcome);
       
       String loginOutcome = newUser.returnLoginStatus(usernamaFromUser, passwordFromUser, firstname, lastname);
       System.out.println(loginOutcome);
       
    
       

    }

    public static boolean checkUsername(String userName) {
        boolean underscore;
        underscore = userName.contains("_");

        if (userName.length() <= 5 && underscore == true) {

            return true;

        }

        return false;
    }

    public static boolean checkPasswordComplexity(String password) {

        // int eightCharectersLong;
        int containCapitalLetter;
        int containNumber;
        char containSpecialCharecter;

        int specialCharacterCount = 0;
        containCapitalLetter = 0;
        containNumber = 0;

        if (password.length() >= 8) {

            for (int i = 0; i < password.length(); i++) {

                containSpecialCharecter = password.charAt(i);
                if (Character.isUpperCase(containSpecialCharecter)) {
                    containCapitalLetter++;
                } else if (Character.isDigit(containSpecialCharecter)) {
                    containNumber++;
                } else {
                    specialCharacterCount++;
                }

            }

            if (containCapitalLetter != 0 && containNumber != 0 && specialCharacterCount != 0) {
                return true;

            } else {
                return false;
            }

        } else {
            return false;
        }

    }

    public String registerUser(String username, String password, String firstname, String lastname) {
        String outputUsernameMessage;
        String outputPasswordMessage;
        String registrationSuccesfulMessage;

        outputUsernameMessage = "";

        outputPasswordMessage = "";
        registrationSuccesfulMessage = "";
        
        if (checkUsername(username))
        {
         outputUsernameMessage= "Username succesfully recorded \n ";
         this.username = username;
            
            
        }
        else {
            outputUsernameMessage= "username is not correctly formated, please insure that your username contains an underscore and is no more than 5 characters";
            
            
        }
        
        if (checkPasswordComplexity(password)){
         outputPasswordMessage= "password succesfully recorded \n";
         this.password= password;
         
            
        }else {
        outputPasswordMessage= "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
    
        }
        
        registrationSuccesfulMessage= outputUsernameMessage + outputPasswordMessage;
        
       
        
        return registrationSuccesfulMessage;
    }
    
    public boolean loginUser(String username, String password){
        if (username.equals(this.username)  && password.equals(this.password)){
            
            
            return true;
            
            
        }
        else
    
        
        return false;
    }
    public String returnLoginStatus(String username, String password, String firstname, String lastname){
        
     String outputStatusMessage;
     
     //outputStatusMessage = "";
     if (loginUser(username, password)){
         outputStatusMessage= "Welcome" + firstname + " " + lastname + " " + " , It is great to see you again. ";
         
         
         
     }
     else {
         outputStatusMessage = "Username or password incorrect, please try again ";
         
         
         
     }
        
        return outputStatusMessage;
        
    }
    }


